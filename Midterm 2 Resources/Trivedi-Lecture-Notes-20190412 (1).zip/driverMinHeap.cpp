#include<iostream>
using namespace std;
#include <stdio.h>      /* printf, scanf, puts, NULL */

#include <fstream>
#include <stdlib.h>
#include <time.h>       /* time */

#define COUNT 10
#include <math.h>

class MinHeap {
private:
  int* heap;
  int capacity;
  int currentSize;

public:
  MinHeap() {
    capacity = 10;
    currentSize = 0;
    heap = new int[capacity];
  }

  MinHeap(int s) {
    capacity = s;
    currentSize = 0;
    heap = new int[capacity];
  }
  
  ~MinHeap() {
    delete[] heap;
  }
  
  void push(int value) {
    if (currentSize == capacity) {
      cout << "Heap overflow" << endl;
    }
    else {
      currentSize++;
      heap[currentSize-1] = value;
      
      int i = currentSize - 1;
      while (parent(i) >= 0 && heap[i] < heap[parent(i)]) {
	swap(heap[i], heap[parent(i)]);
	i = parent(i);
      }
    }
  }
  
  int pop() {
    if (currentSize <= 0) {
      cout << " Heap is empty: returning garbage" << endl;
      return -1;
    }
    else {
      int result = heap[0];
      heap[0] = heap[currentSize-1];
      currentSize = currentSize - 1;
      minHeapify(0);
      return result;
    }
  }

  int peek() {
    if (currentSize <= 0) {
      cout << " Heap is empty: returning garbage" << endl;
      return -1;
    }
    else return heap[0];
  }

  void printHeap() {
    cout << "====================================================="<<endl;
    print2DUtil(0, 0);
    cout << "====================================================="<<endl;
  }

  void traverseAndPrint(int i) {
    traversePrint(i);
  }

private:

  void minHeapify(int index) {
    int min = index;
    if (leftChild(index) < currentSize) {
      if (heap[min] > heap[leftChild(index)]) min = leftChild(index);
    }
    if (rightChild(index) < currentSize) {
      if (heap[min] > heap[rightChild(index)]) min = rightChild(index);
    }

    if (index == min) {
      // Already heapified 
      return;
    }
    else {
      swap(heap[min], heap[index]);
      minHeapify(min);
    }
  }
  int parent(int index) {return (index-1)/2;}
  int leftChild(int index) {return 2*index+1;}
  int rightChild(int index) {return 2*index+2;}
  void swap(int &x, int &y) {int z = x; x = y; y = z;}
  

  void print2DUtil(int root, int space){
    if (root >= currentSize)
      return;
    
    // Increase distance between levels
    space += COUNT;

    // Process right child first
    if (rightChild(root) < currentSize)
      print2DUtil(rightChild(root), space);
    

    // Print current node after space
    // count
    cout<<endl;
    for (int i = COUNT; i < space; i++)
      cout<<" ";
    cout<<heap[root]<<"\n";

    // Process left child
    if (leftChild(root) < currentSize)
      print2DUtil(leftChild(root), space);
    // cout << "Heap: ";
    // for (int i = 0; i < currentSize; i++) {
    //   cout<< heap[i] << " ";
    // }
    // cout << endl;

  }
  void traversePrint(int i) {
    std::ofstream myfile;
    myfile.open ("tree.dot");
    myfile << "digraph graphname {"<<std::endl;
    myfile << "node [margin=0 fontcolor=black style=filled]" << std::endl;
    if (currentSize > 0) {
      myfile<< heap[i] << " [fillcolor = yellow];" << std::endl;
      printTree(myfile, 0);
    }
    myfile << "}"<<std::endl;
    myfile.close();
    system("dot -Tpdf tree.dot> tree.pdf; open tree.pdf");
    getchar();
  }

  void printTree(std::ofstream& myfile, int root) {
    if (root >= currentSize) return;
    else {
      if (leftChild(root) < currentSize) {
	myfile << heap[root]  <<"->" << heap[leftChild(root)] <<"[label=left];"<< std::endl; 
	printTree(myfile, leftChild(root));
      }
      if (rightChild(root) < currentSize) {
	myfile << heap[root]  <<"->" << heap[rightChild(root)] <<"[label=right];" << std::endl;
	printTree(myfile, rightChild(root));
      }
    }
    return;
  }

};

int main() {
  MinHeap MH(20);

  int array[10] = {40, 11, 4, 16, 42, 18, 19, 21, 15, 9};
  int array2[10];

  cout << "input array: " << endl;
  for (int i = 0; i < 10; i++) {
    cout << array[i] << " ";
  }
  cout << endl;
  
  for (int i = 0; i < 10; i++) {
    MH.push(array[i]);
  }
  
  MH.printHeap();
  getchar();
  
  
  for (int i = 0; i < 10; i++) {
    array2[i] = MH.pop(); 
  }

  cout << "Sorted array: " << endl;
  for (int i = 0; i < 10; i++) {
    cout << array2[i] << " ";
  }
  cout << endl;
  
  

  
  return 0;
}

